/* Environment variable utilities */

// Get environment variable with fallbacks for different naming conventions
export function getEnvVar(key: string): string | undefined {
  // Check various sources for environment variables
  if (typeof window !== 'undefined') {
    // Browser environment - check window.process if available
    const windowProcess = (window as any).process;
    if (windowProcess?.env?.[key]) {
      return windowProcess.env[key];
    }
    
    // Check for Supabase secrets in global window object
    const supabaseSecrets = (window as any).__SUPABASE_SECRETS__;
    if (supabaseSecrets?.[key]) {
      return supabaseSecrets[key];
    }
  }
  
  // Node.js environment or build time
  if (typeof process !== 'undefined' && process.env?.[key]) {
    return process.env[key];
  }
  
  // Check Deno environment (for edge functions)
  if (typeof Deno !== 'undefined' && (Deno as any).env?.get?.(key)) {
    return (Deno as any).env.get(key);
  }
  
  return undefined;
}

// Google Maps API Key with multiple fallbacks
export function getGoogleMapsApiKey(): string | undefined {
  // Try multiple environment variable names
  const apiKey = getEnvVar('GOOGLE_MAPS_API_KEY') || 
                 getEnvVar('NEXT_PUBLIC_GOOGLE_MAPS_API_KEY') ||
                 getEnvVar('REACT_APP_GOOGLE_MAPS_API_KEY');
  
  // Debug logging
  if (typeof window !== 'undefined') {
    console.log('Google Maps API Key search:', {
      GOOGLE_MAPS_API_KEY: getEnvVar('GOOGLE_MAPS_API_KEY'),
      NEXT_PUBLIC_GOOGLE_MAPS_API_KEY: getEnvVar('NEXT_PUBLIC_GOOGLE_MAPS_API_KEY'),
      windowProcess: (window as any).process?.env,
      supabaseSecrets: (window as any).__SUPABASE_SECRETS__
    });
  }
  
  return apiKey;
}