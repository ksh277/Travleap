// 다국어 지원을 위한 번역 데이터
export const translations = {
  ko: {
    // 헤더
    home: '홈',
    travel: '여행',
    camping: '캠핑카',
    accommodation: '숙박',
    food: '음식',
    tourism: '관광지',
    popup: '팝업',
    events: '행사',
    partner: '파트너',
    contact: '문의',
    about: '소개',
    login: '로그인',
    logout: '로그아웃',
    signup: '회원가입',
    admin: '관리자',
    mypage: '마이페이지',
    cart: '장바구니',
    
    // 메인 페이지
    discoverShinan: '신안을 발견하세요',
    exploreIslands: '천혜의 자연과 독특한 문화가 어우러진 신안의 섬들을 탐험해보세요',
    checkIn: '체크인',
    checkOut: '체크아웃',
    guests: '인원',
    search: '검색',
    rooms: '객실',
    adults: '성인',
    children: '어린이',
    
    // 카테고리
    allCategories: '전체',
    
    // 공통
    price: '가격',
    rating: '평점',
    reviews: '리뷰',
    book: '예약하기',
    addToCart: '장바구니 담기',
    viewDetails: '상세보기',
    location: '위치',
    
    // 푸터
    getUpdates: 'Get Updates & More',
    thoughtfulThoughts: 'Thoughtful thoughts to your inbox',
    subscribe: '구독',
    needHelp: 'NEED HELP?',
    callUs: 'Call Us',
    emailUs: 'Email Us to',
    company: 'COMPANY',
    aboutUs: 'About Us',
    communityBlog: 'Community Blog',
    rewards: 'Rewards',
    workWithUs: 'Work With Us',
    support: 'SUPPORT',
    account: 'Account',
    legal: 'Legal',
    affiliate: 'Affiliate Program',
    setting: 'SETTING',
    currency: '통화',
    language: '언어',
    
    // 마이페이지
    myProfile: '마이페이지',
    manageProfile: '내 정보와 예약 내역을 관리하세요',
    bookingHistory: '예약 내역',
    favorites: '찜한 상품',
    myReviews: '내 리뷰',
    settings: '설정',
    confirmed: '확정',
    pending: '대기',
    cancelled: '취소',
    edit: '편집',
    save: '저장',
    cancel: '취소'
  },
  en: {
    // Header
    home: 'Home',
    travel: 'Travel',
    camping: 'Camping',
    accommodation: 'Stay',
    food: 'Food',
    tourism: 'Tourism',
    popup: 'Popup',
    events: 'Events',
    partner: 'Partner',
    contact: 'Contact',
    about: 'About',
    login: 'Login',
    logout: 'Logout',
    signup: 'Sign Up',
    admin: 'Admin',
    mypage: 'My Page',
    cart: 'Cart',
    
    // Main page
    discoverShinan: 'Discover Shinan',
    exploreIslands: 'Explore the islands of Shinan where pristine nature and unique culture come together',
    checkIn: 'Check-in',
    checkOut: 'Check-out',
    guests: 'Guests',
    search: 'Search',
    rooms: 'Rooms',
    adults: 'Adults',
    children: 'Children',
    
    // Categories
    allCategories: 'All',
    
    // Common
    price: 'Price',
    rating: 'Rating',
    reviews: 'Reviews',
    book: 'Book Now',
    addToCart: 'Add to Cart',
    viewDetails: 'View Details',
    location: 'Location',
    
    // Footer
    getUpdates: 'Get Updates & More',
    thoughtfulThoughts: 'Thoughtful thoughts to your inbox',
    subscribe: 'Subscribe',
    needHelp: 'NEED HELP?',
    callUs: 'Call Us',
    emailUs: 'Email Us to',
    company: 'COMPANY',
    aboutUs: 'About Us',
    communityBlog: 'Community Blog',
    rewards: 'Rewards',
    workWithUs: 'Work With Us',
    support: 'SUPPORT',
    account: 'Account',
    legal: 'Legal',
    affiliate: 'Affiliate Program',
    setting: 'SETTING',
    currency: 'Currency',
    language: 'Language',
    
    // My Page
    myProfile: 'My Profile',
    manageProfile: 'Manage your information and booking history',
    bookingHistory: 'Booking History',
    favorites: 'Favorites',
    myReviews: 'My Reviews',
    settings: 'Settings',
    confirmed: 'Confirmed',
    pending: 'Pending',
    cancelled: 'Cancelled',
    edit: 'Edit',
    save: 'Save',
    cancel: 'Cancel'
  },
  ja: {
    // ヘッダー
    home: 'ホーム',
    travel: '旅行',
    camping: 'キャンピングカー',
    accommodation: '宿泊',
    food: '食事',
    tourism: '観光地',
    popup: 'ポップアップ',
    events: 'イベント',
    partner: 'パートナー',
    contact: 'お問い合わせ',
    about: '紹介',
    login: 'ログイン',
    logout: 'ログアウト',
    signup: '新規登録',
    admin: '管理者',
    mypage: 'マイページ',
    cart: 'カート',
    
    // メインページ
    discoverShinan: '新安を発見しよう',
    exploreIslands: '手つかずの自然と独特の文化が調和した新安の島々を探索してみてください',
    checkIn: 'チェックイン',
    checkOut: 'チェックアウト',
    guests: '人数',
    search: '検索',
    rooms: '部屋',
    adults: '大人',
    children: '子供',
    
    // カテゴリー
    allCategories: '全て',
    
    // 共通
    price: '価格',
    rating: '評価',
    reviews: 'レビュー',
    book: '予約する',
    addToCart: 'カートに追加',
    viewDetails: '詳細を見る',
    location: '場所',
    
    // フッター
    getUpdates: 'Get Updates & More',
    thoughtfulThoughts: 'Thoughtful thoughts to your inbox',
    subscribe: '購読',
    needHelp: 'お困りですか？',
    callUs: 'お電話',
    emailUs: 'メール',
    company: '会社',
    aboutUs: '私たちについて',
    communityBlog: 'コミュニティブログ',
    rewards: '報酬',
    workWithUs: '一緒に働く',
    support: 'サポート',
    account: 'アカウント',
    legal: '法的',
    affiliate: 'アフィリエイトプログラム',
    setting: '設定',
    currency: '通貨',
    language: '言語',
    
    // マイページ
    myProfile: 'マイページ',
    manageProfile: '個人情報と予約履歴を管理',
    bookingHistory: '予約履歴',
    favorites: 'お気に入り',
    myReviews: 'マイレビュー',
    settings: '設定',
    confirmed: '確定',
    pending: '待機中',
    cancelled: 'キャンセル',
    edit: '編集',
    save: '保存',
    cancel: 'キャンセル'
  },
  zh: {
    // 头部
    home: '首页',
    travel: '旅行',
    camping: '露营车',
    accommodation: '住宿',
    food: '美食',
    tourism: '旅游景点',
    popup: '弹窗',
    events: '活动',
    partner: '合作伙伴',
    contact: '联系我们',
    about: '关于我们',
    login: '登录',
    logout: '退出',
    signup: '注册',
    admin: '管理员',
    mypage: '我的页面',
    cart: '购物车',
    
    // 主页
    discoverShinan: '探索新安',
    exploreIslands: '探索自然风光与独特文化交融的新安群岛',
    checkIn: '入住',
    checkOut: '退房',
    guests: '客人',
    search: '搜索',
    rooms: '房间',
    adults: '成人',
    children: '儿童',
    
    // 分类
    allCategories: '全部',
    
    // 通用
    price: '价格',
    rating: '评分',
    reviews: '评论',
    book: '立即预订',
    addToCart: '加入购物车',
    viewDetails: '查看详情',
    location: '位置',
    
    // 页脚
    getUpdates: 'Get Updates & More',
    thoughtfulThoughts: 'Thoughtful thoughts to your inbox',
    subscribe: '订阅',
    needHelp: '需要帮助？',
    callUs: '致电我们',
    emailUs: '邮件联系',
    company: '公司',
    aboutUs: '关于我们',
    communityBlog: '社区博客',
    rewards: '奖励',
    workWithUs: '与我们合作',
    support: '支持',
    account: '账户',
    legal: '法律',
    affiliate: '联盟计划',
    setting: '设置',
    currency: '货币',
    language: '语言',
    
    // 我的页面
    myProfile: '我的页面',
    manageProfile: '管理您的信息和预订历史',
    bookingHistory: '预订历史',
    favorites: '收藏夹',
    myReviews: '我的评论',
    settings: '设置',
    confirmed: '已确认',
    pending: '待处理',
    cancelled: '已取消',
    edit: '编辑',
    save: '保存',
    cancel: '取消'
  }
};

// 번역 함수
export const t = (key: string, language: string = 'ko'): string => {
  const lang = language as keyof typeof translations;
  return translations[lang]?.[key as keyof typeof translations['ko']] || translations.ko[key as keyof typeof translations['ko']] || key;
};

// 통화 변환율 (실제로는 API에서 가져와야 함)
export const exchangeRates = {
  KRW: 1,
  USD: 0.00075, // 1 KRW = 0.00075 USD
  JPY: 0.11,    // 1 KRW = 0.11 JPY  
  CNY: 0.0054,  // 1 KRW = 0.0054 CNY
  EUR: 0.00069  // 1 KRW = 0.00069 EUR
};

// 통화 심볼
export const currencySymbols = {
  KRW: '₩',
  USD: '$',
  JPY: '¥',
  CNY: '¥',
  EUR: '€'
};

// 가격 변환 함수
export const formatPrice = (priceInKRW: number, currency: string): string => {
  const rate = exchangeRates[currency as keyof typeof exchangeRates] || 1;
  const convertedPrice = Math.round(priceInKRW * rate);
  const symbol = currencySymbols[currency as keyof typeof currencySymbols] || '₩';
  
  if (currency === 'KRW') {
    return `${symbol}${convertedPrice.toLocaleString()}`;
  } else {
    return `${symbol}${convertedPrice.toLocaleString()}`;
  }
};