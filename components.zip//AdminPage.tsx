import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  Search, 
  Filter,
  BarChart3,
  Users,
  Package,
  TrendingUp,
  Calendar,
  MapPin,
  Star
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminPageProps {
  onBack: () => void;
}

interface Product {
  id: string;
  title: string;
  category: string;
  price: number;
  location: string;
  rating: number;
  reviewCount: number;
  image: string;
  description: string;
  status: 'active' | 'inactive';
  createdAt: string;
  featured?: boolean;
}

// 가상의 상품 데이터
const mockProducts: Product[] = [
  {
    id: '1',
    title: '신안 갯벌 투어',
    category: '투어',
    price: 45000,
    location: '증도면',
    rating: 4.8,
    reviewCount: 156,
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=300&h=200&fit=crop',
    description: '신안의 아름다운 갯벌을 체험할 수 있는 투어입니다.',
    status: 'active',
    createdAt: '2024-01-15',
    featured: true
  },
  {
    id: '2',
    title: '바다뷰 민박',
    category: '숙박',
    price: 65000,
    location: '도초면',
    rating: 4.5,
    reviewCount: 89,
    image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=300&h=200&fit=crop',
    description: '바다가 보이는 깨끗한 민박입니다.',
    status: 'active',
    createdAt: '2024-01-10'
  },
  {
    id: '3',
    title: '신안 특산물 맛집',
    category: '음식',
    price: 25000,
    location: '비금면',
    rating: 4.7,
    reviewCount: 234,
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=300&h=200&fit=crop',
    description: '신안 특산물로 만든 전통 요리를 맛볼 수 있습니다.',
    status: 'active',
    createdAt: '2024-01-05'
  }
];

export function AdminPage({ onBack }: AdminPageProps) {
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(mockProducts);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // 새 상품 폼 데이터
  const [newProduct, setNewProduct] = useState({
    title: '',
    category: '',
    price: '',
    location: '',
    image: '',
    description: '',
    featured: false
  });

  const categories = ['투어', '숙박', '음식', '캠핑카', '관광지', '팝업', '행사'];

  // 통계 데이터 계산
  const stats = {
    totalProducts: products.length,
    activeProducts: products.filter(p => p.status === 'active').length,
    totalRevenue: products.reduce((sum, p) => sum + (p.price * p.reviewCount * 0.1), 0),
    avgRating: products.reduce((sum, p) => sum + p.rating, 0) / products.length
  };

  // 필터링 및 검색
  useEffect(() => {
    let filtered = products;

    if (searchQuery) {
      filtered = filtered.filter(product => 
        product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter(product => product.status === selectedStatus);
    }

    setFilteredProducts(filtered);
  }, [searchQuery, selectedCategory, selectedStatus, products]);

  // 상품 추가
  const handleAddProduct = () => {
    if (!newProduct.title || !newProduct.category || !newProduct.price) {
      toast.error('필수 정보를 모두 입력해주세요.');
      return;
    }

    const product: Product = {
      id: Date.now().toString(),
      title: newProduct.title,
      category: newProduct.category,
      price: parseInt(newProduct.price),
      location: newProduct.location,
      rating: 0,
      reviewCount: 0,
      image: newProduct.image || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=300&h=200&fit=crop',
      description: newProduct.description,
      status: 'active',
      createdAt: new Date().toISOString().split('T')[0],
      featured: newProduct.featured
    };

    setProducts(prev => [...prev, product]);
    setNewProduct({
      title: '',
      category: '',
      price: '',
      location: '',
      image: '',
      description: '',
      featured: false
    });
    setIsAddModalOpen(false);
    toast.success('상품이 추가되었습니다.');
  };

  // 상품 수정
  const handleEditProduct = () => {
    if (!editingProduct) return;

    setProducts(prev => 
      prev.map(p => 
        p.id === editingProduct.id 
          ? { ...editingProduct }
          : p
      )
    );
    setEditingProduct(null);
    setIsEditModalOpen(false);
    toast.success('상품이 수정되었습니다.');
  };

  // 상품 삭제
  const handleDeleteProduct = (id: string) => {
    if (confirm('정말 이 상품을 삭제하시겠습니까?')) {
      setProducts(prev => prev.filter(p => p.id !== id));
      toast.success('상품이 삭제되었습니다.');
    }
  };

  // 상품 상태 토글
  const handleToggleStatus = (id: string) => {
    setProducts(prev => 
      prev.map(p => 
        p.id === id 
          ? { ...p, status: p.status === 'active' ? 'inactive' : 'active' }
          : p
      )
    );
    toast.success('상품 상태가 변경되었습니다.');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 헤더 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">관리자 대시보드</h1>
              <p className="text-gray-600">신안 여행 플랫폼 상품 관리</p>
            </div>
            <Button onClick={onBack} variant="outline">
              돌아가기
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid grid-cols-4 w-full max-w-md">
            <TabsTrigger value="dashboard">대시보드</TabsTrigger>
            <TabsTrigger value="products">상품 관리</TabsTrigger>
            <TabsTrigger value="orders">주문 관리</TabsTrigger>
            <TabsTrigger value="users">사용자 관리</TabsTrigger>
          </TabsList>

          {/* 대시보드 탭 */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* 통계 카드 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">총 상품 수</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalProducts}</div>
                  <p className="text-xs text-muted-foreground">
                    활성 상품: {stats.activeProducts}개
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">예상 수익</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ₩{stats.totalRevenue.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    이번 달 예상
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">평균 평점</CardTitle>
                  <Star className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.avgRating.toFixed(1)}</div>
                  <p className="text-xs text-muted-foreground">
                    5점 만점
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">신규 가입</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">+12</div>
                  <p className="text-xs text-muted-foreground">
                    이번 주
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* 최근 상품 목록 */}
            <Card>
              <CardHeader>
                <CardTitle>최근 등록된 상품</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {products.slice(0, 5).map((product) => (
                    <div key={product.id} className="flex items-center space-x-4">
                      <img
                        src={product.image}
                        alt={product.title}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium">{product.title}</h4>
                        <p className="text-sm text-gray-600">{product.category} • {product.location}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">₩{product.price.toLocaleString()}</p>
                        <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                          {product.status === 'active' ? '활성' : '비활성'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 상품 관리 탭 */}
          <TabsContent value="products" className="space-y-6">
            {/* 검색 및 필터 */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>상품 관리</CardTitle>
                  <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-[#8B5FBF] hover:bg-[#7A4FB5]">
                        <Plus className="h-4 w-4 mr-2" />
                        상품 추가
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>새 상품 추가</DialogTitle>
                      </DialogHeader>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium mb-1 block">상품명 *</label>
                          <Input
                            value={newProduct.title}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, title: e.target.value }))}
                            placeholder="상품명을 입력하세요"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium mb-1 block">카테고리 *</label>
                          <Select
                            value={newProduct.category}
                            onValueChange={(value) => setNewProduct(prev => ({ ...prev, category: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="카테고리 선택" />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map((category) => (
                                <SelectItem key={category} value={category}>
                                  {category}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <label className="text-sm font-medium mb-1 block">가격 *</label>
                          <Input
                            type="number"
                            value={newProduct.price}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, price: e.target.value }))}
                            placeholder="가격을 입력하세요"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium mb-1 block">위치</label>
                          <Input
                            value={newProduct.location}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, location: e.target.value }))}
                            placeholder="위치를 입력하세요"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="text-sm font-medium mb-1 block">이미지 URL</label>
                          <Input
                            value={newProduct.image}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, image: e.target.value }))}
                            placeholder="이미지 URL을 입력하세요"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="text-sm font-medium mb-1 block">설명</label>
                          <Textarea
                            value={newProduct.description}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                            placeholder="상품 설명을 입력하세요"
                            rows={3}
                          />
                        </div>
                      </div>
                      <div className="flex justify-end space-x-2 mt-4">
                        <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
                          취소
                        </Button>
                        <Button onClick={handleAddProduct} className="bg-[#8B5FBF] hover:bg-[#7A4FB5]">
                          추가
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-4 mb-4">
                  <div className="flex-1 min-w-[200px]">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="상품명, 위치, 설명으로 검색..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체 카테고리</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="w-[120px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체 상태</SelectItem>
                      <SelectItem value="active">활성</SelectItem>
                      <SelectItem value="inactive">비활성</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* 상품 테이블 */}
                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>상품</TableHead>
                        <TableHead>카테고리</TableHead>
                        <TableHead>가격</TableHead>
                        <TableHead>평점</TableHead>
                        <TableHead>상태</TableHead>
                        <TableHead>등록일</TableHead>
                        <TableHead>작업</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <img
                                src={product.image}
                                alt={product.title}
                                className="w-10 h-10 rounded-lg object-cover"
                              />
                              <div>
                                <div className="font-medium flex items-center">
                                  {product.title}
                                  {product.featured && (
                                    <Badge className="ml-2 bg-orange-100 text-orange-800">
                                      Featured
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-sm text-gray-500 flex items-center">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  {product.location}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{product.category}</Badge>
                          </TableCell>
                          <TableCell>₩{product.price.toLocaleString()}</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                              {product.rating} ({product.reviewCount})
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={product.status === 'active' ? 'default' : 'secondary'}
                              className="cursor-pointer"
                              onClick={() => handleToggleStatus(product.id)}
                            >
                              {product.status === 'active' ? '활성' : '비활성'}
                            </Badge>
                          </TableCell>
                          <TableCell>{product.createdAt}</TableCell>
                          <TableCell>
                            <div className="flex space-x-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingProduct(product);
                                  setIsEditModalOpen(true);
                                }}
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteProduct(product.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 주문 관리 탭 */}
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>주문 관리</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">주문 관리 기능이 곧 추가될 예정입니다.</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 사용자 관리 탭 */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>사용자 관리</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">사용자 관리 기능이 곧 추가될 예정입니다.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* 수정 모달 */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>상품 수정</DialogTitle>
          </DialogHeader>
          {editingProduct && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">상품명</label>
                <Input
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct(prev => 
                    prev ? { ...prev, title: e.target.value } : null
                  )}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">카테고리</label>
                <Select
                  value={editingProduct.category}
                  onValueChange={(value) => setEditingProduct(prev => 
                    prev ? { ...prev, category: value } : null
                  )}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">가격</label>
                <Input
                  type="number"
                  value={editingProduct.price}
                  onChange={(e) => setEditingProduct(prev => 
                    prev ? { ...prev, price: parseInt(e.target.value) || 0 } : null
                  )}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">위치</label>
                <Input
                  value={editingProduct.location}
                  onChange={(e) => setEditingProduct(prev => 
                    prev ? { ...prev, location: e.target.value } : null
                  )}
                />
              </div>
              <div className="col-span-2">
                <label className="text-sm font-medium mb-1 block">설명</label>
                <Textarea
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct(prev => 
                    prev ? { ...prev, description: e.target.value } : null
                  )}
                  rows={3}
                />
              </div>
            </div>
          )}
          <div className="flex justify-end space-x-2 mt-4">
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
              취소
            </Button>
            <Button onClick={handleEditProduct} className="bg-[#8B5FBF] hover:bg-[#7A4FB5]">
              수정
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}