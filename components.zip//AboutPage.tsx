import React from 'react';
import exampleImage from 'figma:asset/463bee682527cc702af5a308a962e192fa7c8ef7.png';

interface AboutPageProps {
  onCategorySelect: (category: string) => void;
}

export function AboutPage({ onCategorySelect }: AboutPageProps) {
  return (
    <div className="min-h-screen">
      {/* 신안 메인 이미지 섹션 */}
      <div className="relative w-full h-screen">
        <img
          src={exampleImage}
          alt="신안 갯벌"
          className="w-full h-full object-cover"
        />
        
        {/* 신안 텍스트 오버레이 */}
        <div className="absolute top-32 left-8 md:left-16 lg:left-24">
          <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-light tracking-wide">
            신안
          </h1>
        </div>
      </div>
    </div>
  );
}