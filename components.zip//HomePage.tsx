import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar as CalendarComponent } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Star, MapPin, Clock, Users, Gift, Sparkles, Calendar, ChevronLeft, ChevronRight, Minus, Plus, ChevronDown, Heart, Zap } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { formatPrice } from '../utils/translations';

interface HomePageProps {
  onCategorySelect: (category: string) => void;
  onSearch: (query: string, filters?: any) => void;
  selectedCurrency?: string;
}

interface Recommendation {
  id: string;
  title: string;
  category: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  isPartner: boolean;
  isSponsor: boolean;
}

export function HomePage({ onCategorySelect, onSearch, selectedCurrency = 'KRW' }: HomePageProps) {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [destination, setDestination] = useState('');
  const [checkInDate, setCheckInDate] = useState<Date | undefined>();
  const [checkOutDate, setCheckOutDate] = useState<Date | undefined>();
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectingCheckIn, setSelectingCheckIn] = useState(true);
  const [isGuestOpen, setIsGuestOpen] = useState(false);
  const [guestCounts, setGuestCounts] = useState({
    rooms: 1,
    adults: 1,
    children: 0
  });

  useEffect(() => {
    fetchRecommendations();
  }, []);

  // 날짜 포맷팅 함수
  const formatDate = (date: Date | undefined) => {
    if (!date) return '';
    return date.toLocaleDateString('ko-KR', {
      month: 'short',
      day: 'numeric'
    });
  };

  // 날짜 선택 처리
  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;
    
    if (selectingCheckIn) {
      setCheckInDate(date);
      setSelectingCheckIn(false);
      // 체크아웃 날짜가 체크인 날짜보다 이전이면 초기화
      if (checkOutDate && date > checkOutDate) {
        setCheckOutDate(undefined);
      }
    } else {
      // 체크아웃 날짜가 체크인 날짜보다 이후인지 확인
      if (checkInDate && date > checkInDate) {
        setCheckOutDate(date);
        setIsCalendarOpen(false);
        setSelectingCheckIn(true);
      }
    }
  };

  // 캘린더 열기
  const openCalendar = () => {
    setSelectingCheckIn(true);
    setIsCalendarOpen(true);
  };

  // 게스트 수 ���데이트
  const updateGuestCount = (type: 'rooms' | 'adults' | 'children', action: 'increase' | 'decrease') => {
    setGuestCounts(prev => ({
      ...prev,
      [type]: action === 'increase' ? prev[type] + 1 : Math.max(0, prev[type] - 1)
    }));
  };

  // 추천 데이터 가져오기
  const fetchRecommendations = async () => {
    try {
      setLoading(true);
      // 실제 API 호출 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockRecommendations: Recommendation[] = [
        {
          id: '1',
          title: '퍼플섬 힐링 투어',
          category: 'tour',
          price: 45000,
          rating: 4.8,
          image: 'https://images.unsplash.com/photo-1730720426620-9b96001122f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdXJwbGUlMjBpc2xhbmQlMjBrb3JlYSUyMHRvdXJpc3QlMjBkZXN0aW5hdGlvbnxlbnwxfHx8fDE3NTc2MDIxMzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
          description: '보라색으로 물든 신안의 대표 관광지에서 특별한 힐링 경험을 즐겨보세요.',
          isPartner: true,
          isSponsor: false
        },
        {
          id: '2',
          title: '소악도 게스트하우스',
          category: 'accommodation',
          price: 80000,
          rating: 4.6,
          image: 'https://images.unsplash.com/photo-1621830019279-c33c2e310d17?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBpc2xhbmQlMjBndWVzdGhvdXNlJTIwYWNjb21tb2RhdGlvbnxlbnwxfHx8fDE3NTc2MDIxNDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
          description: '바다가 보이는 아늑한 게스트하우스에서 편안한 휴식을 취하세요.',
          isPartner: true,
          isSponsor: true
        }
      ];
      
      setRecommendations(mockRecommendations);
    } catch (error) {
      console.error('추천 데이터 로딩 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const categories = [
    { id: 'tour', name: '여행상품', icon: '🗺️', description: '신안의 아름다운 섬들을 탐험' },
    { id: 'accommodation', name: '숙박', icon: '🏨', description: '편안한 휴식을 위한 숙박시설' },
    { id: 'rentcar', name: '캠핑카', icon: '🚗', description: '자유로운 이동을 위한 차량' },
    { id: 'food', name: '음식', icon: '🍽️', description: '신안 특산물과 맛있는 로컬 음식' },
    { id: 'attraction', name: '관광지', icon: '📷', description: '꼭 가봐야 할 신안의 명소들' },
    { id: 'event', name: '팝업/행사', icon: '📅', description: '특별한 행사와 팝업 이벤트' },
    { id: 'package', name: '패키지', icon: '📦', description: '모든 것이 포함된 완전한 여행' }
  ];

  const serviceCards = [
    {
      title: "플레이스 굿즈",
      description: "각 여행지에 해당되는 특이한 굿즈,상품판매",
      icon: <Gift className="h-8 w-8" />,
      color: "bg-blue-50",
      iconColor: "text-blue-600"
    },
    {
      title: "제휴업체와의 할인이벤트",
      description: "약 300여개와 제휴되어 어딜가든지 최대 20%할인",
      icon: <Sparkles className="h-8 w-8" />,
      color: "bg-purple-50",
      iconColor: "text-purple-600"
    },
    {
      title: "AI 맞춤 추천",
      description: "개인의 취향에 맞는 최적의 여행 코스 추천",
      icon: <Star className="h-8 w-8" />,
      color: "bg-yellow-50",
      iconColor: "text-yellow-600"
    }
  ];

  const currentEvents = [
    {
      title: "신안 튤립축제",
      date: "4월 15일 - 5월 15일",
      location: "신안군 증도면",
      description: "화려한 튤립밭에서 즐기는 봄 축제"
    },
    {
      title: "갯벌체험 프로그램",
      date: "연중 운영",
      location: "신안군 도초면",
      description: "신안 갯벌에서 즐기는 특별한 체험"
    },
    {
      title: "천사대교 야간조명",
      date: "매일 일몰 후",
      location: "천사��교",
      description: "아름다운 야간 조명으로 빛나는 천사대교"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div 
        className="relative h-[48vh] bg-cover bg-center bg-no-repeat overflow-hidden"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1693098436985-4a7dece474b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMHBhbG0lMjB0cmVlcyUyMGJlYWNoJTIwdmFjYXRpb258ZW58MXx8fHwxNzU3NTcwNjQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative z-10 container mx-auto px-4 h-full flex flex-col items-center justify-center">
          {/* Main Title */}
          <div className="text-center text-white space-y-3 max-w-4xl mb-8">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-light tracking-wide">
              My Travel Awesomeplan
            </h1>
            <p className="text-sm md:text-base text-white/90 font-light">
              어떤곳을 내게만 여행상품을 찾아볼 느낌이
            </p>
          </div>

          {/* Search Form */}
          <div className="w-full max-w-4xl">
            <div className="bg-white rounded-lg shadow-2xl p-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                {/* 목적지 */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 block">목적지</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="어디로 가실래요?"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                    />
                  </div>
                </div>

                {/* 체크인/체크아웃 */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 block">체크인/아웃</label>
                  <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                    <PopoverTrigger asChild>
                      <div 
                        className="relative cursor-pointer"
                        onClick={openCalendar}
                      >
                        <Calendar className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <div className="w-full pl-10 pr-8 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm bg-white">
                          {checkInDate && checkOutDate ? (
                            <span className="text-gray-700">
                              {formatDate(checkInDate)} - {formatDate(checkOutDate)}
                            </span>
                          ) : checkInDate ? (
                            <span className="text-gray-700">
                              {formatDate(checkInDate)} - 체크아웃
                            </span>
                          ) : (
                            <span className="text-gray-400">날짜 선택</span>
                          )}
                        </div>
                        <ChevronDown className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-80 p-0" align="start">
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="font-medium text-sm">
                            {selectingCheckIn ? '체크인 날짜' : '체크아웃 날짜'} 선택
                          </h4>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                            >
                              <ChevronLeft className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                            >
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <CalendarComponent
                          mode="single"
                          selected={selectingCheckIn ? checkInDate : checkOutDate}
                          onSelect={handleDateSelect}
                          month={currentMonth}
                          onMonthChange={setCurrentMonth}
                          disabled={(date) => {
                            if (selectingCheckIn) {
                              return date < new Date();
                            } else {
                              return date < new Date() || (checkInDate ? date <= checkInDate : false);
                            }
                          }}
                          className="rounded-md border-0"
                        />
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>

                {/* 게스트 */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 block">게스트</label>
                  <Popover open={isGuestOpen} onOpenChange={setIsGuestOpen}>
                    <PopoverTrigger asChild>
                      <div className="relative cursor-pointer">
                        <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <div className="w-full pl-10 pr-8 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm bg-white">
                          <span className="text-gray-700">
                            객실 {guestCounts.rooms}, 성인 {guestCounts.adults}
                            {guestCounts.children > 0 && `, 아동 ${guestCounts.children}`}
                          </span>
                          <ChevronDown className="h-4 w-4 text-gray-400" />
                        </div>
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-64 p-4" align="start">
                      <div className="space-y-4">
                        {/* 객실 */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">객실</span>
                          <div className="flex items-center space-x-3">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateGuestCount('rooms', 'decrease')}
                              disabled={guestCounts.rooms <= 1}
                              className="h-8 w-8 p-0 rounded-full border-gray-300"
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium w-6 text-center text-purple-600">
                              {guestCounts.rooms}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateGuestCount('rooms', 'increase')}
                              disabled={guestCounts.rooms >= 5}
                              className="h-8 w-8 p-0 rounded-full border-gray-300"
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>

                        {/* 성인 */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">성인</span>
                          <div className="flex items-center space-x-3">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateGuestCount('adults', 'decrease')}
                              disabled={guestCounts.adults <= 1}
                              className="h-8 w-8 p-0 rounded-full border-gray-300"
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium w-6 text-center text-purple-600">
                              {guestCounts.adults}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateGuestCount('adults', 'increase')}
                              disabled={guestCounts.adults >= 10}
                              className="h-8 w-8 p-0 rounded-full border-gray-300"
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>

                        {/* 아동 */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">아동</span>
                          <div className="flex items-center space-x-3">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateGuestCount('children', 'decrease')}
                              disabled={guestCounts.children <= 0}
                              className="h-8 w-8 p-0 rounded-full border-gray-300"
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium w-6 text-center text-purple-600">
                              {guestCounts.children}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateGuestCount('children', 'increase')}
                              disabled={guestCounts.children >= 10}
                              className="h-8 w-8 p-0 rounded-full border-gray-300"
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>

                {/* 검색 버튼 */}
                <div className="flex items-end">
                  <Button 
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-md text-sm font-medium"
                    onClick={() => {
                      const searchFilters = {
                        destination,
                        checkInDate: formatDate(checkInDate),
                        checkOutDate: formatDate(checkOutDate),
                        dateRange: checkInDate && checkOutDate 
                          ? `${formatDate(checkInDate)} - ${formatDate(checkOutDate)}`
                          : checkInDate 
                          ? formatDate(checkInDate)
                          : '',
                        guests: `객실 ${guestCounts.rooms}, 성인 ${guestCounts.adults}${guestCounts.children > 0 ? `, 아동 ${guestCounts.children}` : ''}`,
                        rooms: guestCounts.rooms,
                        adults: guestCounts.adults,
                        children: guestCounts.children
                      };
                      onSearch(destination || '신안 여행', searchFilters);
                    }}
                  >
                    검색
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <div className="container mx-auto px-4 py-16 space-y-16">
        {/* Service Cards */}
        <section className="-mt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {serviceCards.map((card, index) => (
              <div key={index} className="text-center">
                <h3 className="text-xl font-semibold mb-4 text-gray-800">{card.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{card.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* 지금 신안은? 섹션 */}
        <section>
          <div className="mb-8">
            <div className="max-w-6xl mx-auto">
              {/* 제목을 카드들과 분리 */}
              <h2 className="text-3xl font-semibold text-gray-800 mb-6">지금 신안은?</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 퍼플섬 카드 */}
                <div>
                  <Card className="overflow-hidden shadow-lg h-[450px] flex flex-col">
                    <div className="relative flex-shrink-0">
                      <ImageWithFallback
                        src="https://images.unsplash.com/photo-1730720426620-9b96001122f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdXJwbGUlMjBpc2xhbmQlMjBrb3JlYSUyMHRvdXJpc3QlMjBkZXN0aW5hdGlvbnxlbnwxfHx8fDE3NTc2MDIxMzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                        alt="퍼플섬"
                        className="w-full h-56 object-cover"
                      />
                      <div className="absolute top-2 left-2 bg-blue-500 text-white px-2 py-1 rounded text-xs font-medium">
                        Featured
                      </div>
                      <div className="absolute top-2 right-2">
                        <Heart className="h-4 w-4 text-white" />
                      </div>
                    </div>
                    <CardContent className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-start text-gray-600 text-sm mb-2">
                          <MapPin className="h-4 w-4 mr-1 mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-1">천리부도 신안군 안좌면 소등무리길 319</span>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800 line-clamp-1">퍼플섬</h3>
                        
                        <div className="flex items-center">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-gray-300 text-gray-300" />
                            <Star className="h-4 w-4 fill-gray-300 text-gray-300" />
                            <span className="ml-2 text-sm text-gray-600">0 리뷰</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center text-gray-600 text-sm">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>1시간</span>
                        </div>
                        <div className="flex items-center text-orange-500 text-sm font-medium">
                          <Zap className="h-4 w-4 mr-1" />
                          <span>from {formatPrice(150, selectedCurrency)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* 플레이스���더 카드 2 */}
                <div>
                  <Card className="overflow-hidden shadow-lg h-[450px] flex flex-col">
                    <div className="h-56 bg-gray-200 flex items-center justify-center flex-shrink-0">
                      <span className="text-gray-400 text-lg">카드 2</span>
                    </div>
                    <CardContent className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-start text-gray-600 text-sm mb-2">
                          <MapPin className="h-4 w-4 mr-1 mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-1">신안군 추천 장소</span>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800 line-clamp-1">추천 장소 2</h3>
                        
                        <div className="flex items-center">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-gray-300 text-gray-300" />
                            <span className="ml-2 text-sm text-gray-600">12 리뷰</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center text-gray-600 text-sm">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>2시간</span>
                        </div>
                        <div className="flex items-center text-orange-500 text-sm font-medium">
                          <Zap className="h-4 w-4 mr-1" />
                          <span>from {formatPrice(200, selectedCurrency)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* 플레이스홀더 카드 3 */}
                <div>
                  <Card className="overflow-hidden shadow-lg h-[450px] flex flex-col">
                    <div className="h-56 bg-gray-200 flex items-center justify-center flex-shrink-0">
                      <span className="text-gray-400 text-lg">카드 3</span>
                    </div>
                    <CardContent className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-start text-gray-600 text-sm mb-2">
                          <MapPin className="h-4 w-4 mr-1 mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-1">신안군 추천 장소</span>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800 line-clamp-1">추천 장소 3</h3>
                        
                        <div className="flex items-center">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="ml-2 text-sm text-gray-600">25 리뷰</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center text-gray-600 text-sm">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>3시간</span>
                        </div>
                        <div className="flex items-center text-orange-500 text-sm font-medium">
                          <Zap className="h-4 w-4 mr-1" />
                          <span>from {formatPrice(300, selectedCurrency)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* 플레이스홀더 카드 4 */}
                <div>
                  <Card className="overflow-hidden shadow-lg h-[450px] flex flex-col">
                    <div className="h-56 bg-gray-200 flex items-center justify-center flex-shrink-0">
                      <span className="text-gray-400 text-lg">카드 4</span>
                    </div>
                    <CardContent className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-start text-gray-600 text-sm mb-2">
                          <MapPin className="h-4 w-4 mr-1 mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-1">신안군 추천 장소</span>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800 line-clamp-1">추천 장소 4</h3>
                        
                        <div className="flex items-center">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <Star className="h-4 w-4 fill-gray-300 text-gray-300" />
                            <span className="ml-2 text-sm text-gray-600">8 리뷰</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center text-gray-600 text-sm">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>4시간</span>
                        </div>
                        <div className="flex items-center text-orange-500 text-sm font-medium">
                          <Zap className="h-4 w-4 mr-1" />
                          <span>from {formatPrice(400, selectedCurrency)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 액티비티 섹션 */}
        <section>
          <div className="mb-8">
            <div className="max-w-6xl mx-auto">
              {/* 제목을 이미지들과 분리 */}
              <h2 className="text-3xl font-semibold text-gray-800 mb-6">액티비티</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 왼쪽 대형 이미지 */}
                <div>
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1633775362385-7f2c55f769ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaW5hbiUyMGlzbGFuZCUyMGtvcmVhJTIwYWN0aXZpdHklMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzU3NjAyMTkyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="신안 액티비티"
                    className="h-[400px] w-full object-cover rounded-lg"
                  />
                </div>
                
                {/* 오른쪽 카드들 */}
                <div>
                  <div className="space-y-4">
                    {/* 소악도 민박 카드 */}
                    <div className="relative">
                      <ImageWithFallback
                        src="https://images.unsplash.com/photo-1621830019279-c33c2e310d17?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBpc2xhbmQlMjBndWVzdGhvdXNlJTIwYWNjb21tb2RhdGlvbnxlbnwxfHx8fDE3NTc2MDIxNDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                        alt="소악도 민박"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-30 rounded-lg flex items-center justify-center">
                        <div className="text-white text-center">
                          <h3 className="text-lg font-semibold">소악도 민박</h3>
                          <p className="text-sm opacity-90">민박</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* 하단 플레이스홀더 */}
                    <div className="h-36 bg-gray-200 rounded-lg flex items-center justify-center">
                      <span className="text-gray-400 text-lg">600 × 400</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Know your city? + 리뷰 섹션 */}
        <section>
          <div className="text-center mb-12">
            <h2 className="text-4xl font-light text-gray-300 mb-8">Know your city?</h2>
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 mb-12">
              Become Local Expert
            </Button>
          </div>
          
          {/* 주변 숙소 살펴보기 */}
          <div className="mb-12">
            <div className="text-center mb-8">
              <div className="inline-block">
                <div className="w-32 h-24 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                  <span className="text-gray-500 text-sm">60일 숙소 00</span>
                </div>
                <h3 className="text-lg font-semibold">주변 숙소 살펴보기</h3>
              </div>
            </div>
          </div>
          
          {/* 리뷰 섹션 */}
          <div className="mb-8">
            <h3 className="text-2xl font-semibold mb-8 text-gray-800">리뷰</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: 'Linda', rating: 5, review: 'Facilisis tristique felis potenti ultricies ornare rhoncus semper hac facilisis tristique felis lorem sem velit dica mauris placerat et dui' },
              { name: 'Lorem', rating: 5, review: 'Facilisis tristique felis potenti ultricies ornare rhoncus semper hac facilisis tristique felis lorem sem velit dica mauris placerat et dui' },
              { name: 'Jinam', rating: 5, review: 'Facilisis tristique felis potenti ultricies ornare rhoncus semper hac facilisis tristique felis lorem sem velit dica mauris placerat et dui' }
            ].map((review, index) => (
              <Card key={index} className="p-6 shadow-sm">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
                    <span className="text-gray-500 text-sm">{review.name.charAt(0)}</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">{review.name}</h4>
                    <div className="text-yellow-500 text-sm">
                      {'⭐'.repeat(review.rating)}
                    </div>
                  </div>
                  <div className="ml-auto text-blue-500 text-3xl">"</div>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed">{review.review}</p>
              </Card>
            ))}
          </div>
          
          {/* 페이지네이션 점들 */}
          <div className="flex justify-center mt-8">
            <div className="flex space-x-2">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
              <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}