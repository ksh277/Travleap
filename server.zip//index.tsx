import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-d9a6f522/health", (c) => {
  return c.json({ status: "ok" });
});

// Categories
app.get("/make-server-d9a6f522/categories", async (c) => {
  try {
    const categories = await kv.get("categories") || {
      tour: { name: "여행상품", icon: "map", description: "신안의 아름다운 섬들을 탐험하는 여행상품" },
      accommodation: { name: "숙박", icon: "bed", description: "편안한 휴식을 위한 숙박시설" },
      rentcar: { name: "캠핑카", icon: "car", description: "자유로운 이동을 위한 캠핑카 서비스" },
      food: { name: "음식", icon: "utensils", description: "신안 특산물과 맛있는 로컬 음식" },
      attraction: { name: "관광지", icon: "camera", description: "꼭 가봐야 할 신안의 명소들" },
      event: { name: "팝업/행사", icon: "calendar", description: "특별한 행사와 팝업 이벤트" },
      package: { name: "패키지", icon: "package", description: "모든 것이 포함된 완전한 여행 패키지" }
    };
    return c.json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    return c.json({ error: "Failed to fetch categories" }, 500);
  }
});

// Get listings by category
app.get("/make-server-d9a6f522/listings/:category", async (c) => {
  try {
    const category = c.req.param("category");
    const listings = await kv.get(`listings_${category}`) || [];
    return c.json(listings);
  } catch (error) {
    console.error("Error fetching listings:", error);
    return c.json({ error: "Failed to fetch listings" }, 500);
  }
});

// Get single listing
app.get("/make-server-d9a6f522/listing/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const listing = await kv.get(`listing_${id}`);
    if (!listing) {
      return c.json({ error: "Listing not found" }, 404);
    }
    return c.json(listing);
  } catch (error) {
    console.error("Error fetching listing:", error);
    return c.json({ error: "Failed to fetch listing" }, 500);
  }
});

// Get recommendations
app.get("/make-server-d9a6f522/recommendations", async (c) => {
  try {
    const recommendations = await kv.get("recommendations") || [];
    return c.json(recommendations);
  } catch (error) {
    console.error("Error fetching recommendations:", error);
    return c.json({ error: "Failed to fetch recommendations" }, 500);
  }
});

// Search listings
app.get("/make-server-d9a6f522/search", async (c) => {
  try {
    const query = c.req.query("q") || "";
    const category = c.req.query("category");
    const results = await kv.get("search_results") || [];
    
    // Simple search implementation
    let filteredResults = results;
    if (query) {
      filteredResults = results.filter((item: any) => 
        item.title?.toLowerCase().includes(query.toLowerCase()) ||
        item.description?.toLowerCase().includes(query.toLowerCase())
      );
    }
    if (category && category !== "all") {
      filteredResults = filteredResults.filter((item: any) => item.category === category);
    }
    
    return c.json(filteredResults);
  } catch (error) {
    console.error("Error searching listings:", error);
    return c.json({ error: "Failed to search listings" }, 500);
  }
});

// Partner application
app.post("/make-server-d9a6f522/partner/apply", async (c) => {
  try {
    const body = await c.req.json();
    const applicationId = `partner_app_${Date.now()}`;
    
    const application = {
      id: applicationId,
      ...body,
      status: "pending",
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`partner_application_${applicationId}`, application);
    
    return c.json({ 
      success: true, 
      applicationId,
      message: "파트너 신청이 성공적으로 접수되었습니다." 
    });
  } catch (error) {
    console.error("Error submitting partner application:", error);
    return c.json({ error: "Failed to submit application" }, 500);
  }
});

// Create booking
app.post("/make-server-d9a6f522/booking", async (c) => {
  try {
    const body = await c.req.json();
    const bookingId = `booking_${Date.now()}`;
    
    const booking = {
      id: bookingId,
      ...body,
      status: "pending",
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`booking_${bookingId}`, booking);
    
    return c.json({ 
      success: true, 
      bookingId,
      message: "예약이 성공적으로 접수되었습니다." 
    });
  } catch (error) {
    console.error("Error creating booking:", error);
    return c.json({ error: "Failed to create booking" }, 500);
  }
});

// Add review
app.post("/make-server-d9a6f522/review", async (c) => {
  try {
    const body = await c.req.json();
    const reviewId = `review_${Date.now()}`;
    
    const review = {
      id: reviewId,
      ...body,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`review_${reviewId}`, review);
    
    // Update listing reviews
    const listingReviews = await kv.get(`reviews_${body.listingId}`) || [];
    listingReviews.push(review);
    await kv.set(`reviews_${body.listingId}`, listingReviews);
    
    return c.json({ 
      success: true, 
      reviewId,
      message: "리뷰가 성공적으로 등록되었습니다." 
    });
  } catch (error) {
    console.error("Error adding review:", error);
    return c.json({ error: "Failed to add review" }, 500);
  }
});

// Get reviews for listing
app.get("/make-server-d9a6f522/reviews/:listingId", async (c) => {
  try {
    const listingId = c.req.param("listingId");
    const reviews = await kv.get(`reviews_${listingId}`) || [];
    return c.json(reviews);
  } catch (error) {
    console.error("Error fetching reviews:", error);
    return c.json({ error: "Failed to fetch reviews" }, 500);
  }
});

// Contact form
app.post("/make-server-d9a6f522/contact", async (c) => {
  try {
    const body = await c.req.json();
    const contactId = `contact_${Date.now()}`;
    
    const contact = {
      id: contactId,
      ...body,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`contact_${contactId}`, contact);
    
    return c.json({ 
      success: true, 
      contactId,
      message: "문의가 성공적으로 접수되었습니다." 
    });
  } catch (error) {
    console.error("Error submitting contact:", error);
    return c.json({ error: "Failed to submit contact" }, 500);
  }
});

// Initialize sample data
app.post("/make-server-d9a6f522/init-data", async (c) => {
  try {
    // Sample recommendations
    const recommendations = [
      {
        id: "rec1",
        title: "신안 천사대교 일출투어",
        category: "tour",
        price: 45000,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1746427397703-ea04f0b59e14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaGluYW4lMjBpc2xhbmQlMjBrb3JlYSUyMGNvYXN0YWwlMjBzY2VuZXJ5fGVufDF8fHx8MTc1NzU2OTYwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "아름다운 천사대교에서 감상하는 황홀한 일출",
        isPartner: true,
        isSponsor: false
      },
      {
        id: "rec2",
        title: "신안 바다정원 민박",
        category: "accommodation",
        price: 80000,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1712880437462-f1ef10364859?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGhvdGVsJTIwYWNjb21tb2RhdGlvbnxlbnwxfHx8fDE3NTc1Njk2MDd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "바다 전망이 아름다운 전통 한옥 민박",
        isPartner: true,
        isSponsor: true
      },
      {
        id: "rec3",
        title: "신안 전복요리 맛집",
        category: "food",
        price: 25000,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1703925155035-fd10b9c19b24?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBsb2NhbCUyMGZvb2QlMjBzZWFmb29kfGVufDF8fHx8MTc1NzU2OTYwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "신안 특산 전복으로 만든 신선한 해산물 요리",
        isPartner: true,
        isSponsor: false
      },
      {
        id: "rec4",
        title: "신안 섬투어 패키지",
        category: "package",
        price: 120000,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1666507074532-ec7a461de551?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3VyJTIwZ3JvdXAlMjB0cmF2ZWwlMjBrb3JlYXxlbnwxfHx8fDE3NTc1Njk2MTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "신안의 아름다운 섬들을 모두 둘러보는 완전한 투어 패키지",
        isPartner: true,
        isSponsor: true
      },
      {
        id: "rec5",
        title: "신안 캠핑카 프리미엄",
        category: "rentcar",
        price: 60000,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1684082018938-9c30f2a7045d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjByZW50YWwlMjBzZXJ2aWNlfGVufDF8fHx8MTc1NzUwODExNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "신안 여행을 위한 깨끗하고 편안한 프리미엄 캠핑카",
        isPartner: true,
        isSponsor: false
      }
    ];
    
    await kv.set("recommendations", recommendations);
    
    // Sample tour listings
    const tourListings = [
      {
        id: "tour1",
        title: "신안 천사대교 일출투어",
        category: "tour",
        price: 45000,
        rating: 4.8,
        reviewCount: 127,
        image: "https://images.unsplash.com/photo-1746427397703-ea04f0b59e14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaGluYW4lMjBpc2xhbmQlMjBrb3JlYSUyMGNvYXN0YWwlMjBzY2VuZXJ5fGVufDF8fHx8MTc1NzU2OTYwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "신안의 상징 천사대교에서 감상하는 황홀한 일출 투어입니다. 새벽 5시에 출발하여 최고의 일출 포인트에서 멋진 사진도 찍어드립니다.",
        duration: "3시간",
        included: ["가이드", "이동차량", "기념품"],
        location: "신안군 증도면",
        isPartner: true,
        isSponsor: false,
        partnerName: "신안투어"
      },
      {
        id: "tour2",
        title: "신안 갯벌체험 투어",
        category: "tour",
        price: 35000,
        rating: 4.6,
        reviewCount: 89,
        image: "https://images.unsplash.com/photo-1746427397703-ea04f0b59e14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaGluYW4lMjBpc2xhbmQlMjBrb3JlYSUyMGNvYXN0YWwlMjBzY2VuZXJ5fGVufDF8fHx8MTc1NzU2OTYwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        description: "신안 갯벌에서 직접 조개와 낙지를 잡아보는 체험 투어",
        duration: "2시간",
        included: ["체험도구", "가이드", "간식"],
        location: "신안군 도초면",
        isPartner: true,
        isSponsor: true,
        partnerName: "갯벌체험마을"
      }
    ];
    
    await kv.set("listings_tour", tourListings);
    
    return c.json({ message: "Sample data initialized successfully" });
  } catch (error) {
    console.error("Error initializing data:", error);
    return c.json({ error: "Failed to initialize data" }, 500);
  }
});

Deno.serve(app.fetch);